package es.indra.cursoJava.entidades;

public class Paleta  {
	private double peso;

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		this.peso = peso;
	}

	public Paleta(String tipoCerdo, double pesoCerdo, int numCortesCerdo, String alimentacionCerdo, double peso) {
		super();
		this.peso = 5.2;
	}

	@Override
	public String toString() {
		return "Paleta [peso=" + peso + ", getPeso()=" + getPeso() + "]";
	}
	
	public double calculaPeso(){
		return this.peso*2;
	}

}
