package es.indra.cursoJava.entidades;

public class Solomillo  {
	private double peso;
	private double grosor;

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		this.peso = peso;
	}

	public double getGrosor() {
		return grosor;
	}

	public void setGrosor(double grosor) {
		this.grosor = grosor;
	}

	public Solomillo(String tipoCerdo, double pesoCerdo, int numCortesCerdo, String alimentacionCerdo, double peso,
			double grosor) {
		super();
		this.peso = 0.8;
		this.grosor = 1.1;
	}

	@Override
	public String toString() {
		return "Solomillo [peso=" + peso + ", grosor=" + grosor + ", getPeso()=" + getPeso() + ", getGrosor()="
				+ getGrosor() + "]";
	}
	
	public double calculaGrosor(){
		return this.grosor;
	}

}
