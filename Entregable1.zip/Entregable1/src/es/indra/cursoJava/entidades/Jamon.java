package es.indra.cursoJava.entidades;

public class Jamon extends CorteCerdo {
	private boolean esIberico;
	private String marca;
	private double peso;

	public boolean isEsIberico() {
		return esIberico;
	}

	public void setEsIberico(boolean esIberico) {
		this.esIberico = esIberico;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		this.peso = peso;
	}

	public Jamon(String tipoCerdo, double pesoCerdo, int numCortesCerdo, String alimentacionCerdo, boolean esIberico,
			String marca, double peso) {
		super(tipoCerdo, pesoCerdo, numCortesCerdo, alimentacionCerdo);
		this.esIberico = true;
		this.marca = "Navidul";
		this.peso = 10.3;
	}

	@Override
	public String toString() {
		if (this.esIberico) {
			return "Es Ib�rico";
		} else {
			return "No es ib�rcio";

		}
	}
	
	public String diMarca(){
		return this.marca;
	}

}
