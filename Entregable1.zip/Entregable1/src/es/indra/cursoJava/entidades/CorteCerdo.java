package es.indra.cursoJava.entidades;

public class CorteCerdo {
	private String tipoCerdo;
	private double pesoCerdo;
	private int numCortesCerdo;
	private String alimentacionCerdo;

	private String getTipoCerdo() {
		return tipoCerdo;
	}

	public void setTipoCerdo(String tipoCerdo) {
		this.tipoCerdo = tipoCerdo;
	}

	public double getPesoCerdo() {
		return pesoCerdo;
	}

	public void setPesoCerdo(double pesoCerdo) {
		this.pesoCerdo = pesoCerdo;
	}

	public int getNumCortesCerdo() {
		return numCortesCerdo;
	}

	public void setNumCortesCerdo(int numCortesCerdo) {
		this.numCortesCerdo = numCortesCerdo;
	}

	public String getAlimentacionCerdo() {
		return alimentacionCerdo;
	}

	public void setAlimentacionCerdo(String alimentacionCerdo) {
		this.alimentacionCerdo = alimentacionCerdo;
	}

	public CorteCerdo(String tipoCerdo, double pesoCerdo, int numCortesCerdo, String alimentacionCerdo) {
		super();
		this.tipoCerdo = "Ib�rcio";
		this.pesoCerdo = 70.0;
		this.numCortesCerdo = 4;
		this.alimentacionCerdo = "Bellota";
	}

	@Override
	public String toString() {
		return "CorteCerdo [tipoCerdo=" + tipoCerdo + ", pesoCerdo=" + pesoCerdo + ", numCortesCerdo=" + numCortesCerdo
				+ ", alimentacionCerdo=" + alimentacionCerdo + ", getTipoCerdo()=" + getTipoCerdo()
				+ ", getPesoCerdo()=" + getPesoCerdo() + ", getNumCortesCerdo()=" + getNumCortesCerdo()
				+ ", getAlimentacionCerdo()=" + getAlimentacionCerdo() + "]";
	}
	
	public String diAlimentacion(){
		return this.alimentacionCerdo;
	}

}
