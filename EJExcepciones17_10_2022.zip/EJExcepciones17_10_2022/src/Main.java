import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Elemento>listaGon=new ArrayList<>();
		Elemento nuevoElemento = new Elemento();

		nuevoElemento.setNumero(10);
		System.out.println(nuevoElemento.numero);
	}

}
