package es.indra;

import org.springframework.stereotype.Service;

@Service
public class ServicioA {
	public String metodo1() {
		return "hola es el metodo1";
	}
}
