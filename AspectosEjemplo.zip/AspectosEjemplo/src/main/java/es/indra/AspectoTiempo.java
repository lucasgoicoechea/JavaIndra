package es.indra;

import java.util.List;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class AspectoTiempo {

	private static List<ServicioA> ServicioA = null;

	@Before("execution(public * get*())")
	public void loggingAdvice1(JoinPoint joinpoint) {
		System.out.println("Before advice is executed");
	}

	@AfterReturning("execution(public * get*())")
	public void loggingAdvice5() {
		System.out.println("AfterReturning advice is run");
	}

	@Cacheable("servicioA")
	public List<ServicioA> findAll() {
		return ServicioA;
	}

	@Around("execution(* es.indra.*.*(..))")
	public Object calculoTiempo(ProceedingJoinPoint joinPoint) throws Throwable {
		long t1 = System.currentTimeMillis();
		Object resultado = joinPoint.proceed();
		long t2 = System.currentTimeMillis();
		if (t2 - t1 > 2000) {
			System.out.println("Metodo lento:" + joinPoint.getTarget().getClass() + "."
					+ joinPoint.getSignature().getName() + ":" + (t2 - t1));
		}
		return resultado;
	}
}
