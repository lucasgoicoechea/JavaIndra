package Main;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Controlador {

	public Clases.Modelo modelo;

	public Controlador(Clases.Modelo modelo){
		this.modelo=modelo;
	}

	public Controlador() {
		super();
	}

}
