package Main;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Clases.Modelo modelo = new Clases.Modelo();
		

	}

}
