package Clases;

public class PaisOrigen {
	String idioma;
	String nombre;
	public String getIdioma() {
		return idioma;
	}
	public void setIdioma(String idioma) {
		this.idioma = idioma;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public PaisOrigen(String idioma, String nombre) {
		super();
		this.idioma = idioma;
		this.nombre = nombre;
	}
	@Override
	public String toString() {
		return "PaisOrigen [idioma=" + idioma + ", nombre=" + nombre + "]";
	}
	
	
}
