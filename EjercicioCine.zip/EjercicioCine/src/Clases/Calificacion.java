package Clases;

public class Calificacion {
	String nombre;

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Calificacion(String nombre) {
		super();
		this.nombre = nombre;
	}

	@Override
	public String toString() {
		return "Calificacion [nombre=" + nombre + "]";
	}

	
}
