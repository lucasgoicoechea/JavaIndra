package com.indra.demo;

import java.util.Optional;

public interface PersonaService {

	<S extends PersonaVO> S save(S entity);

	<S extends PersonaVO> Iterable<S> saveAll(Iterable<S> entities);

	Optional<PersonaVO> findById(Integer id);

	boolean existsById(Integer id);

	Iterable<PersonaVO> findAll();

	Iterable<PersonaVO> findAllById(Iterable<Integer> ids);

	long count();

	void deleteById(Integer id);

	void delete(PersonaVO entity);

	void deleteAllById(Iterable<? extends Integer> ids);

	void deleteAll(Iterable<? extends PersonaVO> entities);

	void deleteAll();

}