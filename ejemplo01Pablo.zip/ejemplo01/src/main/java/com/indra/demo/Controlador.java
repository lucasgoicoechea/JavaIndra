package com.indra.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;

@Controller
@CrossOrigin(origins ="HTTP://LOCALHOST:4200")
public class Controlador {
	
	@Autowired
	PersonaService ps;

	
}
