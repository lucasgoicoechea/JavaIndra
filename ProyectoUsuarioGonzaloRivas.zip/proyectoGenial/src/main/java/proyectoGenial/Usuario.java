package proyectoGenial;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Usuario implements Serializable {

	private static final long serialVersionUID = -29807264209266036L;
	long id;
	String nombre;
	String primerApellido;
	String segundoApellido;
	String mail;
	String telefono;

}
